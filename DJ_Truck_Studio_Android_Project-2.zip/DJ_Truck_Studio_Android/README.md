# DJ Truck Studio

Android project for a 3D DJ truck builder prototype.

Features in this version:
- 3D truck scene
- Add/remove subwoofers, speakers, moving heads, PAR lights and LED bars
- Move selected equipment
- Truck color control
- Static, RGB Chase, Bass Pulse, Strobe and Party lighting modes
- Load music from the phone
- Bass-reactive light intensity
- Touch camera controls
